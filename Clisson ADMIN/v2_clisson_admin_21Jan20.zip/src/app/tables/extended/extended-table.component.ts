import { Component } from '@angular/core';

@Component({
    selector: 'app-extended-table',
    templateUrl: './extended-table.component.html',
    styleUrls: ['./extended-table.component.scss']
})

export class ExtendedTableComponent {

}