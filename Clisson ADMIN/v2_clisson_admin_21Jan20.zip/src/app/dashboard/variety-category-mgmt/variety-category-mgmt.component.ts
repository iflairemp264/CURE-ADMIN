import { Component, OnInit } from '@angular/core';
import { AuthService } from 'app/shared/auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { environment } from '../../../environments/environment'
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-variety-category-mgmt',
  templateUrl: './variety-category-mgmt.component.html',
  styleUrls: ['./variety-category-mgmt.component.scss']
})
export class VarietyCategoryMgmtComponent implements OnInit {
  varietyCategoryList = [];
  imgurl = `${environment.api.baseurlImg}`
  search: any
  maxPage: any
  total_record: any
  page: number = 1
  order: boolean = true
  orderBy: any
  // orderBy: any
  searchValue: any
  constructor(
    private authService: AuthService,
    private toast: ToastrService,
    private route: Router,
    private titleService: Title
  ) { }

  ngOnInit() {
    this.getList(this.page, this.orderBy)
    this.searchValue = null
    if (this.searchValue == null) {
      this.search = false
    }
    this.titleService.setTitle('Espèces-ID JARDIN')
  }

  onChange(variety_status, varietyid) {

    Swal.fire({
      title: 'Êtes-vous sûr?',
      text: "Le statut de l'espèce sera modifié!",
      showCancelButton: true,
      confirmButtonText: 'Oui, supprimez le!',
      cancelButtonText: 'Non, gardez le!'
    }).then((result) => {
      let temp;
      if (result.value == true) {
        if (variety_status == 0) {
          temp = 1
        }
        else {
          temp = 0;
        }
        let obj = {
          'id': JSON.parse(varietyid),
          'status': JSON.stringify(temp)
        }
        this.authService.changeVarietyCategoryStatus(obj).subscribe((res) => {
          if (res && res['status'] == 200) {
            this.toast.success(res['message']);
            this.ngOnInit();
          }
          else {
            this.toast.warning(res['message']);
            this.ngOnInit();
          }
        })
      }
      else {
        this.ngOnInit();
      }
    })
  }
  getList(page, orderBy) {
    this.authService.getVarietyCategoryList(page, orderBy).subscribe(res => {
      if (res && res['status'] == 200) {
        this.varietyCategoryList = res['data'];
        this.maxPage = res['maxPage']
        this.total_record = res['totalRecords']
      }
    })
  }

  onDeleteConfirm(id) {
    Swal.fire({
      title: 'Êtes-vous sûr?',
      text: 'Cette espèce sera supprimée',
      showCancelButton: true,
      confirmButtonText: 'Oui, supprimez la!',
      cancelButtonText: 'Non, gardez la!'
    }).then((result) => {
      if (result.value == true) {
        this.authService.deleteVarietyCategory(id).subscribe((res) => {
          if (res && res['status'] == 200) {
            this.toast.success(res['message'])
            this.ngOnInit();
          }
        })
      }
      else {
        this.ngOnInit();
      }
    })
  }
  searchRecord(term) {
    if (term.length > 1) {
      this.search = true
      this.authService.searchCategory(term).subscribe(res => {
        if (res && res['status'] == 400) {
          this.varietyCategoryList = res['results']
        }
      })
    }
    else {
      this.search = false
      this.ngOnInit();
    }
  }
  shortRecord() {
    if (this.search == false) {
      this.order = !this.order
      if (this.order == true) {
        this.orderBy = 'ASC'
      } else {
        this.orderBy = 'DESC'
      }

      this.getList(this.page, this.orderBy)
    }
    else {

      this.varietyCategoryList.sort((b, a) => 0 - (a > b ? -1 : 1));
    }

    // this.varietyCategoryList.sort((b, a) => 0 - (a > b ? -1 : 1));

  }
}
