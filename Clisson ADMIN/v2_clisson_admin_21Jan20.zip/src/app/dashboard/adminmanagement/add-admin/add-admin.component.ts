import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup, NgForm, FormControl, FormControlName } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'app/shared/auth/auth.service';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.scss']
})
export class AddAdminComponent implements OnInit {
  AdminAddForm: FormGroup;
  selectedStatus: any
  statusData = [{
    id: '0', value: 'Activé'
  },
  { id: '1', value: 'Désactivé' }
  ]
  @ViewChild('f', { static: false }) floatingLabelForm: NgForm;
  @ViewChild('vform', { static: false }) validationForm: FormGroup;
  constructor(
    private toast: ToastrService,
    private authService: AuthService,
    private route: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.AdminAddForm = new FormGroup({
      'name': new FormControl(null, [Validators.required]),
      'password': new FormControl(null, [Validators.required, Validators.minLength(4), Validators.maxLength(24)]),
      'status': new FormControl(null, [Validators.required, Validators.pattern('[0-1]'), Validators.maxLength(1)])
      // 'confirm_password': new FormControl('',Validators.required)

    }, { updateOn: 'blur' });

  }

  onAdminAddFormSubmit(value) {
    let obj = {
      'name': value.name,
      'password': value.password,
      'status': this.selectedStatus
    }
    this.authService.addUser(obj).subscribe(res => {
      if (res && res['status'] == 200) {
        this.toast.success(res['message']);
        this.AdminAddForm.reset();
        this.route.navigate(['/admin']);
      }
      else {
        this.AdminAddForm.reset();
        this.route.navigate(['/admin']);
      }
    })
  }
  onClickCancel() {
    this.route.navigate(['/admin'])
  }

  statusSelect(status) {
    this.selectedStatus = status
  }
}
