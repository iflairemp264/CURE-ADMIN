import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'app/shared/auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';
import { environment } from '../../../environments/environment'
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-recipe-details-mgmt',
  templateUrl: './recipe-details-mgmt.component.html',
  styleUrls: ['./recipe-details-mgmt.component.scss']
})
export class RecipeDetailsMgmtComponent implements OnInit {
  recipe: any = [];
  imgurl = `${environment.api.baseurlImg}`
  total_records: any
  pageNo: number = 1
  searchValue: any
  search: any
  order: boolean = true
  orderBy: any
  maxPage: any
  constructor(private route: Router,
    private authService: AuthService,
    private titleService: Title,
    private toast: ToastrService) { }

  ngOnInit() {
    this.recipeList(this.pageNo, this.orderBy);
    this.searchValue = null
    if (this.searchValue == null) {
      this.search = false
    }
    this.titleService.setTitle('Recettes-ID JARDIN')
  }

  recipeList(pageNo, orderBy) {
    this.authService.getRecipeList(pageNo, orderBy).subscribe(res => {
      if (res && res['status'] == 200) {
        this.recipe = res['data']
        this.total_records = res['totalRecords']
        this.maxPage = res['maxPage']
      }
    })
  }
  onChangeStatus(event, id) {

    Swal.fire({
      title: 'Êtes-vous sûr?',
      text: "Le statut de la recette sera modifié!",
      showCancelButton: true,
      confirmButtonText: 'Oui, changez le!',
      cancelButtonText: "Non, gardez le!"
    }).then((result) => {
      let temp;
      if (result.value == true) {
        if (event == 0) {
          temp = 1
        }
        else {
          temp = 0;
        }
        let obj = {
          'id': JSON.parse(id),
          'status': JSON.stringify(temp)
        }
        this.authService.changeReciepeStatus(obj).subscribe((res) => {
          if (res && res['status'] == 200) {
            this.toast.success(res['message']);
            this.ngOnInit();
          }
          else {
            this.toast.warning(res['message']);
            this.ngOnInit();
          }
        })
      }
      else {
        this.ngOnInit();
      }
    })
  }

  onDeleteConfirm(id) {
    Swal.fire({
      title: 'Êtes-vous sûr?',
      text: "La recette sera supprimée",
      showCancelButton: true,
      confirmButtonText: 'Oui, supprimez la!',
      cancelButtonText: "Non, gardez la!"
    }).then((result) => {
      if (result.value == true) {
        this.authService.deleteRecipe(id).subscribe((res) => {
          if (res && res['status'] == 200) {
            this.toast.success(res['message'])
            this.ngOnInit();
          }
          else {
            this.toast.warning(res['message'])
          }
        })
      }
      else {
        this.ngOnInit();
      }
    })
  }
  serchRecord(term) {
    if (term.length > 1) {
      this.search = true
      this.authService.searchRecipe(term).subscribe(res => {

        if (res && res['status'] == 400) {
          this.recipe = res['results']
          if (this.recipe && this.recipe.length > 0) {
            // for (let i = 0; i < this.recipe.length; i++) {
            // this.recipe[i] = {
            //   picture: this.recipe[i].image,
            //   name : this.recipe[i].name,
            //   varieties_used:this.recipe[i].varieties_used,
            //   number_of_persons:this.recipe[i].number_of_persons,
            //   status:this.recipe[i].status
            // }
            // }
          }
        }
      })
    }
    else {
      this.ngOnInit()
      this.search = false
    }

  }
  shortRecord() {
    if (this.search == false) {
      this.order = !this.order
      if (this.order == true) {
        this.orderBy = 'ASC'
      } else {
        this.orderBy = 'DESC'
      }

      this.recipeList(this.pageNo, this.orderBy)
    }
    else{

      this.recipe.sort((b, a) => 0 - (a > b ? -1 : 1));
    }

  }

}
