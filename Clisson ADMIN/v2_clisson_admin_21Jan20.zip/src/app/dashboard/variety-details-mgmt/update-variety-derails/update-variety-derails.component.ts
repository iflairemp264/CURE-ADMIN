import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'app/shared/auth/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-update-variety-derails',
  templateUrl: './update-variety-derails.component.html',
  styleUrls: ['./update-variety-derails.component.scss']
})
export class UpdateVarietyDerailsComponent implements OnInit {
  updateVarietyForm: FormGroup
  reletedprod: any
  relatedVariety2: any
  selectedProdId: any
  selectedVarietyProd: any
  fileObject: any;
  updateRecord: any
  category = [];
  cat_id: any
  SelectedCategory: any
  imgUrl = `${environment.api.baseurlImg}`;
  baseurl = `${environment.api.baseurl}`;
  id: any
  relatedId = []
  selectedStatus: any
  deleted_img: any = []
  // q1value ="BIO"
  private url = `${environment.api.baseurl}`;
  statusData = [
    {
      id: '0', value: 'Activé'
    },
    { id: '1', value: 'Désactivé' }
  ]
  seletcedPremium: any
  PremiumData = [
    {
      id: '0', value: 'Defaut'
    },
    {
      id: '1', value: 'Niveau 1'
    },
    {
      id: '2', value: 'Niveau 2'
    }
  ]
  Q1 = "Quel type de culture souhaitez-vous?"
  Q1Options = [
    { id: '0', value: 'Conventionnel', lable: 'Conventionnel' },
    { id: '1', value: 'BIO', lable: 'BIO' },
    { id: '2', value: 'Sans traitement après récolte', lable: 'Sans traitement après récolte' },
    // { id: '3', value: '', lable: 'Non de ci-dessus' }

  ]
  Q1SelectedOpt: any
  Q2 = "Quelle est la nature de votre sol?"
  Q2Options = [
    { id: '0', value: 'LIMONEUX', lable: 'Limoneux' },
    { id: '1', value: 'ARGILEUX', lable: 'Argileux' },
    { id: '2', value: 'SABLEUX', lable: 'Sableux' },
    { id: '3', value: 'CALCAIRE', lable: 'Calcaire' },
    { id: '4', value: 'ARGILO-CALCAIRE', lable: 'Argilo-Calcaire' },
    // { id: '5', value: '', lable: 'Non de ci-dessus' }
  ]
  Q2SelectedOpt: any
  Q3 = "Quelle est la destination culinaire?"
  Q3Options = [
    { id: '0', value: 'Toutes utilisations culinaires', lable: 'Toutes utilisations culinaires' },
    { id: '1', value: 'Frite four purée potage', lable: 'Frite four purée potage' },
    { id: '2', value: 'Salade Vapeur Mitonnée Rissolée', lable: 'Salade vapeur mitonnée rissolée' },
    // { id: '3', value: '', lable: 'Non de ci-dessus' }
  ]
  Q3SelectedOpt: any
  Q4 = 'Quand souhaitez-vous planter?'
  Q4Options = [
    { id: '0', value: 'Automne', lable: 'Automne' },
    { id: '1', value: 'Printemps', lable: 'Printemps' },
    // { id: '2', value: '', lable: 'Non de ci-dessus' }
  ]
  Q4SelectedOpt: any

  Q5 = 'Quel temp de conservation souhaitez-vous?'
  Q5Options = [
    { id: '0', value: 'De 0 à 1 mois', lable: 'De 0 à 1 mois' },
    { id: '1', value: 'De 2 à 3 mois', lable: 'De 2 à 3 mois' },
    { id: '2', value: 'De 3 à 4 mois', lable: 'De 3 à 4 mois' },
    { id: '3', value: 'De 5 à 6 mois', lable: 'De 5 à 6 mois' },
    { id: '4', value: 'De 6 à 7 mois', lable: 'De 6 à 7 mois' },
    { id: '5', value: '8 mois et plus', lable: '8 mois et plus' },
    // { id: '6', value: '', lable: 'Non de ci-dessus' }
  ]
  Q5SelectedOpt: any

  Q6 = 'Quelle période de maturité désirez-vous?'
  Q6Options = [
    { id: '0', value: 'Tardive', lable: 'Tardive' },
    { id: '1', value: 'Normale', lable: 'Normale' },
    { id: '2', value: 'Hâtive', lable: 'Hâtive' },
    { id: '3', value: 'Tres Hâtive', lable: 'Tres Hâtive' },
    { id: '4', value: 'Super Hâtive', lable: 'Super Hâtive' },
    // { id: '5', value: '', lable: 'Non de ci-dessus' }
  ]
  Q6SelectedOpt: any
  constructor(private toast: ToastrService,
    private authService: AuthService,
    private route: Router,
    private activatedRoute: ActivatedRoute,
    private http: HttpClient) { }

  ngOnInit() {

    this.getCategoryList()
    this.updateVarietyForm = new FormGroup({
      'name': new FormControl(null, [Validators.required]),
      'description': new FormControl(null, [Validators.required]),
      'yield': new FormControl(null, [Validators.required]),
      'preservation': new FormControl(null, Validators.required),
      'skinColor': new FormControl(null, [Validators.required]),
      'fleshColor': new FormControl(null, [Validators.required]),
      'category_id': new FormControl(null, [Validators.required]),
      'status': new FormControl(null, [Validators.required]),
      'variety_Img': new FormControl(null),
      'relatedVariety': new FormControl(null, [Validators.required]),
      'small': new FormControl(null, [Validators.required]),
      'medium': new FormControl(null, [Validators.required]),
      'maturation_time': new FormControl(null, [Validators.required]),
      'big': new FormControl(null, [Validators.required]),
      'mildew_resistance': new FormControl(null, [Validators.required]),
      'premium': new FormControl(null, Validators.required),
      // New Fields ad

      'shape_of_the_seed': new FormControl(null, [Validators.required]),
      'shape_of_the_harvested_product': new FormControl(null, [Validators.required]),
      'proportion_of_large_caliber': new FormControl(null, [Validators.required]),
      'taste': new FormControl(null, [Validators.required]),
      'holding_with_cooking': new FormControl(null, [Validators.required]),
      'blackening_on_cooking': new FormControl(null, [Validators.required]),
      'resistance_to_foliage_blight': new FormControl(null, [Validators.required]),
      'resistance_to_common_scab': new FormControl(null, [Validators.required]),
      'foliage': new FormControl(null, [Validators.required]),
      'flower': new FormControl(null, [Validators.required]),
      'flowering': new FormControl(null, [Validators.required]),
      'category': new FormControl(null, [Validators.required]),
      'q1': new FormControl(null, [Validators.required]),
      'q2': new FormControl(null, [Validators.required]),
      'q3': new FormControl(null, [Validators.required]),
      'q4': new FormControl(null, [Validators.required]),
      'q5': new FormControl(null, [Validators.required]),
      'q6': new FormControl(null, [Validators.required]),
    }, { updateOn: 'blur' });

    if (this.activatedRoute.snapshot.queryParams['id']) {
      this.id = this.activatedRoute.snapshot.queryParams['id']

      this.authService.varietyDetail(this.id).subscribe(res => {
        if (res && res['status'] == 200) {
          this.updateRecord = res['data']
          // console.log("updateRecord", this.updateRecord);
          this.cat_id = this.updateRecord.category_id
          this.reletedprod = res['relatedAdmin']
          this.reletedprod['1'].map(x => {
            if (x) this.relatedId.push(x.id)
          })
          this.reletedprod['2'].map(x => {
            if (x) this.relatedId.push(x.id)
          })
          this.reletedprod['default'].map(x => {
            if (x) this.relatedId.push(x.id)
          })
          this.selectedVarietyProd = [...this.relatedId]
          // console.log("ProdId Related",this.selectedVarietyProd);

          let obj = {
            'category_id': this.cat_id
          }
          this.authService.getRelatedVariety(obj).subscribe(res => {

            if (res && res['status'] == 200) {
              this.relatedVariety2 = res['data']
              this.selectedProdId = this.relatedVariety2.filter(x => {
                if (this.relatedId.length > 0) return this.relatedId.includes(x.id)
              })

            }
          })

          /* temp1.filter(x=>temp2.includes(x.id)) */

          this.updateVarietyForm.patchValue({
            'name': this.updateRecord.name,
            'description': this.updateRecord.description,
            'yield': this.updateRecord.yield,
            'preservation': this.updateRecord.preservation,
            'skinColor': this.updateRecord.skin_color,
            'fleshColor': this.updateRecord.flesh_color,
            'category_id': this.updateRecord.category_id,
            'status': this.updateRecord.status,
            'relatedVariety': this.selectedVarietyProd,
            'small': this.updateRecord.small,
            'medium': this.updateRecord.medium,
            'big': this.updateRecord.big,
            'mildew_resistance': this.updateRecord.mildew_resistance,
            'premium': this.updateRecord.premium_variety,
            'maturation_time': this.updateRecord.maturation_time,
            'shape_of_the_seed': this.updateRecord.shape_of_the_seed,
            'shape_of_the_harvested_product': this.updateRecord.shape_of_the_harvested_product,
            'proportion_of_large_caliber': this.updateRecord.proportion_of_large_caliber,
            'taste': this.updateRecord.taste,
            'holding_with_cooking': this.updateRecord.holding_with_cooking,
            'blackening_on_cooking': this.updateRecord.blackening_on_cooking,
            'resistance_to_foliage_blight': this.updateRecord.resistance_to_foliage_blight,
            'resistance_to_common_scab': this.updateRecord.resistance_to_common_scab,
            'foliage': this.updateRecord.foliage,
            'flower': this.updateRecord.flower,
            'flowering': this.updateRecord.flowering,
            'category': this.updateRecord.category,
            'q1': this.updateRecord.q1,
            'q2': this.updateRecord.q2,
            'q3': this.updateRecord.q3,
            'q4': this.updateRecord.q4,
            'q5': this.updateRecord.q5,
            'q6': this.updateRecord.q6,

          })
          // setTimeout(()=>{
          //   this.updateVarietyForm.controls['q1'].setValue(this.Q1Options[0].value)
          // },1000)
          // console.log(this.updateVarietyForm.controls);
        }
      })
    }

  }
  onSubmit(value) {
    let formData: FormData = new FormData();
    if (this.fileObject) {
      for (let i = 0; i < this.fileObject.length; i++) {
        const element = this.fileObject[i];
        formData.append('varietyCat_img', element);
      }
    }
    formData.append('variety_id', this.id)
    formData.append('name', value.name)
    formData.append('description', value.description)
    formData.append('yield', value.yield)
    formData.append('preservation', value.preservation)
    formData.append('skinColor', value.skinColor)
    formData.append('fleshColor', value.fleshColor)
    formData.append('category_id', value.category_id)
    formData.append('status', this.selectedStatus)
    formData.append('relatedVariety', value.relatedVariety)
    formData.append('small', value.small)
    formData.append('medium', value.medium)
    formData.append('big', value.big)
    formData.append('premium_variety', this.seletcedPremium)
    formData.append('maturation_time', value.maturation_time)
    formData.append('mildew_resistance', value.mildew_resistance)
    formData.append('del_img', this.deleted_img)

    formData.append('shape_of_the_seed', value.shape_of_the_seed)
    formData.append('shape_of_the_harvested_product', value.shape_of_the_harvested_product)
    formData.append('proportion_of_large_caliber', value.proportion_of_large_caliber)
    formData.append('taste', value.taste)
    formData.append('holding_with_cooking', value.holding_with_cooking)
    formData.append('blackening_on_cooking', value.blackening_on_cooking)
    formData.append('resistance_to_foliage_blight', value.resistance_to_foliage_blight)
    formData.append('resistance_to_common_scab', value.resistance_to_common_scab)
    formData.append('foliage', value.foliage)
    formData.append('flower', value.flower)
    formData.append('flowering', value.flowering)
    formData.append('category', value.category)
    formData.append('q1', value.q1)
    formData.append('q2', value.q2)
    formData.append('q3', value.q3)
    formData.append('q4', value.q4)
    formData.append('q5', value.q5)
    formData.append('q6', value.q6)
    let headers = new HttpHeaders({
      'Authorization': localStorage.getItem('_token'),
    });

    this.http.post(`${this.url}/variety/edit`, formData, { headers })
      .pipe(map((res: any) => {

        if (res && res['status'] == 200) {
          this.toast.success(res['message']);
          this.route.navigate(['/variety']);
        }
        else {
          this.toast.warning(res['message']);
          this.route.navigate(['/variety']);
        }
      }))
      .subscribe(data => { }, error => {
        console.log(error);
      })
  }

  onClickCancel() {
    this.route.navigate(['/variety']);
  }
  handleFileInput(imgObj) {
    for (let i = 0; i < imgObj.length; i++) {
      if (imgObj[i].size > 150000) {
        this.toast.warning("la taille de l'image doit être inférieure à 150 Ko");
      }
      this.fileObject = imgObj
    }

  }
  getCategoryList() {
    this.authService.getAllVarietyCategoryList().subscribe(res => {
      if (res && res['data']) {
        this.category = res['data']
      }
    })
  }
  selectedOption(value) {
    this.updateVarietyForm.controls['relatedVariety'].setValue['']
    this.selectedVarietyProd = []
    this.SelectedCategory = value.id
    let obj = {
      'category_id': this.SelectedCategory
    }
    this.authService.getRelatedVariety(obj).subscribe(res => {
      if (res && res['status'] == 200) {
        this.relatedVariety2 = res['data']
      }
    })
  }
  onRemoveImg(item) {

    let index = this.updateRecord.pictures.findIndex(x => x == item)
    this.updateRecord.pictures.splice(index, 1)
    this.deleted_img.push(item.images)
  }
}
