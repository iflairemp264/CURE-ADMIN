import { TestBed } from '@angular/core/testing';

import { ServicestitleService } from './servicestitle.service';

describe('ServicestitleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ServicestitleService = TestBed.get(ServicestitleService);
    expect(service).toBeTruthy();
  });
});
