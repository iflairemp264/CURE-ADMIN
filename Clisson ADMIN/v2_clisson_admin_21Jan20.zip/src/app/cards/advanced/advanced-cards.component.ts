import { Component } from '@angular/core';

@Component({
    selector: 'app-advanced-cards',
    templateUrl: './advanced-cards.component.html',
    styleUrls: ['./advanced-cards.component.scss']
})

export class AdvancedCardsComponent {

}