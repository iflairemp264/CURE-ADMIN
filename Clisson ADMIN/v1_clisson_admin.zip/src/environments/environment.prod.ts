export const environment = {
  production: true,
  api:{
    // baseurl:'http://176.31.215.237:5000'
    // baseurl:'http://35.180.66.181/api'
    baseurl: 'http://206.189.135.176/clisson-server/api',
    baseurlImg: 'http://206.189.135.176/clisson-server/images'
  }
};
